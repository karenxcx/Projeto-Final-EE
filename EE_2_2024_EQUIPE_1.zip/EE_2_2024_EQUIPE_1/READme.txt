Link de acesso aos videos: 

https://drive.google.com/open?id=1FWCDHHO8BB23i_lZVPPpNJxtO2V5lbDR&usp=drive_fs