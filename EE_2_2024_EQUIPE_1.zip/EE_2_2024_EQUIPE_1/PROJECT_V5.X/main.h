/* 
 * File:   
 * Author: Grupo 1
 * Comments:
 * Revision history: 
 */
/*/PINOS 
 
 RA0 - Lim - Limite da v�lvula;        RB0 - Echo - sensor ultrassom; 
 RA1 - SM1 - Status Motor;             RB1 - UART_Rx - Bluetooth;
 RA2 - SM2 - Status Motor;             RB2 - UART_Tx - Bluetooth;
 RA3 - SM3 - Status Motor;             RB3 - Vent - aciona a ventoinha;
 RA4 - SM4 - Status Motor;             RB4 - Temp - Sensor de temperatura;
 RA5 - MCLR - faz nada;                RB5 - vazio
 RA6 - Trigger - sensor ultrassom;     RB6 - CSPCLK - faz nada;
 RA7 - LED - apenas um led;            RB7 - ICSPDAT - faz nada; 
 /*/

/*/Dados anal�gicos
 Sensor �ptico TCRT-5000 - 0V: valvula aberta, 5V: valvula fechada
 Sensor ultrassom HC-SR04 - altura da bola
 Sensor temperatura LM35 - compensa��o para altura da bola
 * Todos conectados em VDD = 5V; 
 * RA0: INPUT  - Lim     - sensor �ptico;
 * RA6: INPUT  - Echo    - sensor ultrassom;
 * RB4: INPUT  - Temp    - sensor de temperatura; 
 * RB0: OUTPUT - Trigger - sensor ultrassom;
 * RA7: OUTPUT - LED;
 /*/

/*/Comunica��o Bluetooth
 * UART
 * RB1 - UART_Rx: 7 bytes;
 *      CH0: Modo de funcionamento; 
 *      CH1: setpoint_1: MSB
 *      CH2: setpoint_1: LSB
 *      CH3: setpoint_2: MSB
 *      CH4: setpoint_2: LSB
 * RB2 - UART_Tx: 15 bytes;
 *      CH00: Modo de funcionamento; 
 *      CH01: setpoint_altura [mm]   : MSB
 *      CH02: setpoint_altura [mm]   : LSB
 *      CH03: altura medida   [mm]   : MSB
 *      CH04: altura medida   [mm]   : LSB 
 *      CH05: tempo_de_voo    [ms]   : MSB
 *      CH06: tempo_de_voo    [ms]   : LSB
 *      CH07: temperatura     [�C]   : MSB
 *      CH08: temperatura     [�C]   : LSB
 *      CH09: setpoint_valvula [step]: MSB
 *      CH10: setpoint_valvula [step]: LSB
 *      CH11: posicao_valvula  [step]: MSB
 *      CH12: posicao_valvula  [step]: LSB
 *      CH13: dutycycle_pwm  [0-1023]: MSB
 *      CH14: dutycycle_pwm  [0-1023]: LSB

 /*/

/*/Controle da Ventoinha
* RB3: PWM - Controle da ventoinha;             
 /*/

/*/Controle Motor de Passo ULN3003
* RA1: OUTPUT - SM1 - Status Motor;             
* RA2: OUTPUT - SM2 - Status Motor;             
* RA3: OUTPUT - SM3 - Status Motor;             
* RA4: OUTPUT - SM4 - Status Motor;             
 /*/

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <math.h>

/* Medi��o da Altura da Bola*/

#define T0      273.15       // [K]   - Temperatura em Kelvin a 0C;
#define C0      331.3        // [m/s] - Velocidade do som a 0C; 
#define COEF    0.0488       // Coeficiente para convers�o para 0C = 50/1023
    
#define COMP    CMOUTbits.MC1OUT
#define ANTIHORARIO 0       // Sentido de fechar a porta
#define HORARIO     1       // Sentido de abrir a porta

/* Vari�veis de controle PI*/

#define KC 1.0
#define T 0.01
#define Ti 0.01
#define Td 0.1

float T_Ti = T/Ti;

float ek = 0;           // erro atual
float ek_1 = 0;         // erro passado
float uk = 0;           // saida 
float uk_1 = 0;         // saida pr�-calculada
int24_t kpf = 21;                       //ganho proporcional do fluxo
int24_t kdf = 109;                      //ganho derivativo do fluxo
int24_t kpp = 32;                       //ganho proporcional do pwm do motor
int24_t kip = 17;                       //ganho integrativo do pwm do motor
int24_t kdp = 15;                       //ganho derivativo do pwm do motor
uint16_t output;
int timecontrol = 4;
int24_t outputsum;


/* Modos de opera��o */

typedef enum {
    MANUAL, 
    VENTOINHA,
    VALVULA,
    RESET
}opmode; 

typedef union{
    uint16_t total;
    struct{
        uint8_t LSB;
        uint8_t MSB;
    };
} uint16_var;

typedef struct{
    uint8_t funcmode; 
    uint16_var setpoint_height; 
    uint16_var height; 
    uint16_var time_of_flight;
    uint16_var temperature;
    uint16_var setpoint_valve;
    uint16_var pos_valve;
    uint16_var dutycycle_pwm;
} TxData;
TxData data;

uint8_t bufferRx[7] = {0,0,0,0,0,0,0};
uint8_t countRx = 0, count_10ms = 0;
uint16_t setpwm = 0; 
uint16_t pos_motor = 0;         // Variavel que guarda a posicao da valvula
uint16_t setpos_motor = 0;      // Setpoint para posicao da valvula
uint16_t step;                  // Incremento do passo do motor
//float temperature_kelvin = 0, soundspeed = 0;
uint8_t temperature_index = 0;
uint16_t soundspeed_t;
uint8_t rxChar;

bool fim_curso = true;                 ///< Variavel booleana que indica se a porta chegou ao fim de curso (completamente aberta), ou nao
bool passo_ctrl = false;        ///< Variavel utilizada no while para fazer com que a funcao fluxpos (a qual chama a funcao daUmPasso) seja chamada a cada 8ms 

void Initialcase();
void calculateHeight();        
void calculateToF();
void setpwm_dutycycle();

void valvemotor(uint8_t passom, uint8_t sentido);
void controlmode();
void count10ms();
void analisaRx();
void enviaTx();

void setstep(uint8_t sentido); //daumpasso
void fluxcontrol();
void pwmcontrol();
void fluxpos();

/*/Valores para constante de Velocidade do som em [m/s]*250[ns]/2 para temperaturas de 0�C a 50�C */
const float LUTsoundspeed[51] = {
0.041413, 0.041488, 0.041564, 0.041639, 0.041715, 0.041790, 0.041865, 0.041940, 0.042015, 0.042089, 0.042164, 0.042238, 
0.042312, 0.042387, 0.042461, 0.042534, 0.042608, 0.042682, 0.042755, 0.042829, 0.042902, 0.042975, 0.043048, 0.043121, 
0.043194, 0.043266, 0.043339, 0.043411, 0.043483, 0.043555, 0.043627, 0.043699, 0.043771, 0.043843, 0.043914, 0.043986, 
0.044057, 0.044128, 0.044199, 0.044270, 0.044341, 0.044412, 0.044483, 0.044553, 0.044623, 0.044694, 0.044764, 0.044834, 
0.044904, 0.044974, 0.045044};







#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

