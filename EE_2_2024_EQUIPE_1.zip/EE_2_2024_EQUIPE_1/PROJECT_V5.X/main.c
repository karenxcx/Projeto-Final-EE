           /**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name: Projeto Final Grupo 1 
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "main.h"
//#include <stdbool.h>

void main(void){
    // initialize the device
    SYSTEM_Initialize();
    TMR4_SetInterruptHandler(count10ms);
    TMR1_SetInterruptHandler(calculateToF);
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
        
    while (1){
     
            if(EUSART_is_rx_ready()){           // Se chega um byte
                uint8_t rxChar = EUSART_Read(); // Se guarda em rxChar
                if (countRx < 7){
                    bufferRx[countRx] = rxChar;
                    countRx++;
                }
                if (countRx >= 7){
                    analisaRx();
                    countRx = 0;
                }
            }
            if (count_10ms == 10){
                enviaTx();
                count_10ms = 0;
            }
        LED_LAT = COMP;
    }
}

void Initialcase(){
    while(!CMP1_GetOutputStatus()){         //Equanto nao tem sinal do sensor infra vermelho, ou seja, equanto nao estiver na posicao 0
        setstep(HORARIO);                     //Da passos no sentido horario a cada 6ms
        __delay_ms(5);
    }
    //Quando chegar na posicao 0
    fim_curso = 1;                       //Ativa flag que indica que a calibracao da valvula foi concluida
    pos_motor = 0;                           //Zera a posicao
}

void setstep(uint8_t sentido) {
    if (fim_curso) {                        // Testa se o fim de curso da porta foi atingido durante a execucao
        if(sentido == HORARIO){             // Para o sentido horario (abertura da porta), decrementa a posicao da porta
            pos_motor--;
        } 
        else if(sentido == ANTIHORARIO){    // Para o sentido anti-horario (fechamento da porta), incrementa a posicao da porta
            pos_motor++;
        }
        valvemotor(step, sentido);   // Chama a funcao que define o passo do motor, de acordo com o sentido definido, apos o fim de curso ser confirmado
    } else {
        valvemotor(step, HORARIO);   // Se o fim de curso nunca foi antingido, a abertura da porta continua ate a posicao da porta ser zerada
    }
}

void valvemotor(uint8_t passom, uint8_t sentido) {
    if (sentido == HORARIO) {       // Funcionamento das bobinas para o sentido horario (abertura)
        switch(passom) {
            case 0: SM1_SetHigh(); SM2_SetHigh(); SM3_SetLow(); SM4_SetLow(); break;
            case 1: SM1_SetLow(); SM2_SetHigh(); SM3_SetHigh(); SM4_SetLow(); break;
            case 2: SM1_SetLow(); SM2_SetLow(); SM3_SetHigh(); SM4_SetHigh(); break;
            case 3: SM1_SetHigh(); SM2_SetLow(); SM3_SetLow(); SM4_SetHigh(); break;
        }
    }
    else if(sentido == ANTIHORARIO){  // Funcionamento das bobinas para o sentido anti-horario (fechamento)
        switch(passom) {
            case 0: SM4_SetHigh(); SM3_SetHigh(); SM2_SetLow(); SM1_SetLow(); break;
            case 1: SM4_SetLow(); SM3_SetHigh(); SM2_SetHigh(); SM1_SetLow(); break;
            case 2: SM4_SetLow(); SM3_SetLow(); SM2_SetHigh(); SM1_SetHigh(); break;
            case 3: SM4_SetHigh(); SM3_SetLow(); SM2_SetLow(); SM1_SetHigh(); break;
        }
    } 
    step++;
    step = step & 0x03; // atualiza step e aplica m�scara
}



void calculateToF(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    
    while(!Echo_PORT);  // Aguarda borda de subida (in�cio do ECHO)
    TMR1_WriteTimer(0);
    TMR1_StartTimer();
    while(Echo_PORT);   // Aguarda borda de descida (fim do ECHO)
    TMR1_StopTimer();
    data.time_of_flight.total = TMR1_ReadTimer();
    // Converte de contagens de Timer1 para ms
    data.time_of_flight.total = (uint16_t)data.time_of_flight.total;
}

void calculateHeight(){
    data.temperature.total = ADC_GetConversion(Temp);
    data.temperature.total = (uint16_t)( COEF *data.temperature.total);            // Converte valor para [�C] inteiro
    if (data.temperature.total < 0) data.temperature.total = 0;               // Temperatura m�nima em 0�C
    if (data.temperature.total > 50) data.temperature.total = 50;             // Temperatura m�xima em 50�C
    temperature_index =(uint16_t) data.temperature.total; 
    soundspeed_t = (uint16_t)LUTsoundspeed[temperature_index];                          //Calcula velocidade do som [m/s]
    data.height.total = (data.time_of_flight.total*soundspeed_t/2);         //Altura em [mm]
}

void count10ms(void) {
    count_10ms++;
}

void fluxpos(){
    if(data.funcmode == VALVULA){                           //Se o funcionamento atual e valvula 
        if(output>pos_motor) setstep(ANTIHORARIO);         //Da um passo anti-horario se a saida do controle for maior que a posicao atual da valvula
        else if(output<pos_motor) setstep(HORARIO);        //Da um passo horario se a saida do controle for maior que a posicao atual da valvula
    }
    else{                                                   //Se o funcionamento atual eh manual ou ventoinha
        if(setpos_motor>pos_motor) setstep(ANTIHORARIO);    //Da um passo anti-horario se a posicao desejada for maior que a posicao atual da valvula
        else if(setpos_motor<pos_motor) setstep(HORARIO);   //Da um passo horario se a posicao desejada for maior que a posicao atual da valvula
        else {                                              //Desliga as bobinas se a posicao atual for a desejada
            SM4_SetLow();
            SM3_SetLow();
            SM2_SetLow();
            SM1_SetLow();
        }
    }
}

void controlmode(){
        if (data.funcmode == VENTOINHA){                        //escolhendo qual malha de controle sera utilizada de acordo com a variavel que indica o modo de funcionamento atual
        pwmcontrol ();          
    } else if(data.funcmode == VALVULA){
        fluxcontrol ();
    }                                                       //Caso o modo de funcionamento atual seja o manual (00), essa funcao nao chama nenhuma das malhas de controle
    TMR4_StartTimer();
}
    
void fluxcontrol(){
    ek = (data.setpoint_height.total - data.height.total)*100; //Calculo do erro baseado na dist setado com a dist real, *10 pra duas casas decimais
    if(ek > 150 || ek < - 150){ // Caso o erro seja maior do que 5%
        uk = (((kpf* ek + kdf*(ek - ek_1)))+uk); // definindo output com kpf e voltando a escala
        if (uk > 0) output = 0; //saturando o output
        else if(uk <-40000 ) output = 400;  //saturando output
        else output = (uint16_t)- uk/100; //invertendo o uk e colocando em ponto fix, invers�o por conta do mov da porta
        if (uk>800){
            uk = 800; //saturando novamente
        } else if (uk < -45000){
            uk = -45000;
        }
        ek_1 = ek; //error atual vira o erro passado
        
    }
}

void pwmcontrol(){
    ek = (data.setpoint_height.total - data.height.total);          //Calculo do erro baseado na dist setado com a dist real
    if(ek > 15 || ek < -15){         // Caso o erro seja maior do que 5%, roda o codigo
        outputsum += ((kip*timecontrol*ek)/10);     //Kintegrativa com erro e o tempo do timer 
        if (outputsum > 100) outputsum = 100;       //saturando o outputsum
        else if (outputsum< -10) outputsum = -10;
        uk = (kpp*ek + outputsum + (kdp*(ek-ek_1))+uk); //voltando a escala padrao
        if(uk > 6230){     //saturando o output
            output = 1023;
        }
        else if(uk <0) { //saturando o output novamente
            output= 0+400;
        } else {
            output = ((uint16_t)uk/10) + 400;
        }
        if (uk>6230){
            uk = 6230;
        } else if (uk < -800){
            uk = -800;
        }
        
        EPWM1_LoadDutyValue(output); //mandando o valor apos o controle
        ek_1 = ek;                      //error atual vira o error passado
        
    }
}
    
   
void analisaRx(){
    switch(bufferRx[0]){
        case MANUAL:
            if (countRx==7){
                data.funcmode = bufferRx[0];
                data.setpoint_valve.MSB = bufferRx[3];
                data.setpoint_valve.LSB = bufferRx[4];
                if (data.setpoint_valve.total > 420) data.setpoint_valve.total = 420;
                data.dutycycle_pwm.MSB = bufferRx[5];
                data.dutycycle_pwm.LSB = bufferRx[6];
                EPWM1_LoadDutyValue(data.dutycycle_pwm.total);
            }
            countRx = 0;
            break; 
        case VENTOINHA:
            if (countRx==7){
                data.funcmode = bufferRx[0];
                data.setpoint_height.MSB = bufferRx[1];
                data.setpoint_height.LSB = bufferRx[2];
                data.setpoint_valve.MSB = bufferRx[3];
                data.setpoint_valve.LSB = bufferRx[4];
                if (data.setpoint_valve.total > 420) data.setpoint_valve.total = 420;
                if (data.setpoint_valve.total < 0) data.setpoint_valve.total = 0;
                outputsum = 0;
                ek = 0;
                ek_1 = 0;
            }
            countRx = 0;
            break;
        case VALVULA:
            if (countRx==7){
                data.funcmode = bufferRx[0];
                data.setpoint_height.MSB = bufferRx[1];
                data.setpoint_height.LSB = bufferRx[2];
                data.height.total = data.setpoint_height.total;
                data.dutycycle_pwm.MSB = bufferRx[5];
                data.dutycycle_pwm.LSB = bufferRx[6];
                EPWM1_LoadDutyValue(data.dutycycle_pwm.total);
                outputsum = 0;
                ek = 0;
                ek_1 = 0;
            }
            countRx = 0;
            break;
        case RESET:
            if (countRx==7){
               RESET();
            }
            countRx = 0;
            break;
        default: 
            countRx = 0;
    }
    
}

void enviaTx(){
        EUSART_Write(data.funcmode);
        EUSART_Write(data.setpoint_height.MSB);
        EUSART_Write(data.setpoint_height.LSB);
        EUSART_Write(data.height.MSB);
        EUSART_Write(data.height.LSB);
        EUSART_Write(data.time_of_flight.MSB);
        EUSART_Write(data.time_of_flight.LSB);
        EUSART_Write(data.setpoint_valve.MSB);
        EUSART_Write(data.setpoint_valve.LSB);
        EUSART_Write(data.pos_valve.MSB);
        EUSART_Write(data.pos_valve.LSB);
        EUSART_Write(data.dutycycle_pwm.MSB);
        EUSART_Write(data.dutycycle_pwm.LSB);
}
