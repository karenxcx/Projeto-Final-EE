/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name: Projeto Final Grupo 2 
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "main.h"
#include <stdbool.h>



void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    LeituraValvula(true);  // Realiza calibra��o no in�cio

    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    while (1)
    {
        calculateHeight();
        calculateToF();
        __delay_ms(100);
        if (Modo_Operacao == VENTOINHA || Modo_Operacao == VALVULA) { // Se o modo de opera��o for ventoinha ou valvula, chama a fun��o de controle PID
            Controle();
        }
        else if (Modo_Operacao == RESET_) {
            asm("RESET_"); // Reseta o Pic
        }
        ajustaPwm(128);
        __delay_ms(500);

        AbreValvula();
        __delay_ms(1000);

        FechaValvula();
        __delay_ms(1000);
        
    }
}

void triggerUltrasonic(){
//    Trigger_SetHigh();
//    __delay_us(10);
//    Trigger_SetLow();
//    TMR1_Initialize();
}

void calculateToF(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    
    while(!Echo_PORT);  // Aguarda borda de subida (in�cio do ECHO)
    TMR1_WriteTimer(0);
    TMR1_StartTimer();
    while(Echo_PORT);   // Aguarda borda de descida (fim do ECHO)
    TMR1_StopTimer();
    time_of_flight = TMR1_ReadTimer();
    // Converte de contagens de Timer1 para ms
    time_of_flight = time_of_flight * 0.00025;
    
}

float calculateHeight(){
    temperature = ADC_GetConversion(Temp);
    temperature = (int)( COEF *(float) temperature);    // Converte valor para [�C] inteiro
    if (temperature < 0) temperature = 0;               // Temperatura m�nima em 0�C
    if (temperature > 50) temperature = 50;             // Temperatura m�xima em 50�C
    temperature_index = temperature; 
    soundspeed_t = LUTsoundspeed[temperature_index];            //Calcula velocidade do som [m/s]
    height = (time_of_flight*soundspeed/2);             //Altura em [mm]

}


//Fun��o para calcular o erro e retornar o ajuste que deve ser feito na ventoinha ou na v�lvula
int ControleAjuste() {
    float erroAtual = (float)(height_desejada - height); //Mede a diferen�a entre a altura desejada e a altura lida
    erroAcumulado += erroAtual; //Soma o erro ao longo do tempo para eliminar o erro estacion�rio.
    float deltaErro = erroAtual - erroAnterior; // Mede a taxa de varia��o do erro, ajudando a evitar oscila��es excessivas.
    erroAnterior = erroAtual;
    
    return (int)(ganhoK * erroAtual + tempoK * erroAcumulado + ganhoD * deltaErro); //C�lculo da sa�da do controlador PI
}

void Controle() {
    //Alterar_PWM = enviado = false;
    int ajuste = ControleAjuste();        // Obt�m o valor de ajuste necess�rio para reduzir o erro entre o valor medido e o valor desejado.
    if (Modo_Operacao == VENTOINHA) {     // Se o sistema est� no modo VENTOINHA, chama ajustaPwm
        ajustaPwm(ajuste);
    } else {                              // Se est� no modo VALVULA, chama ajustaValvula
        ajustaValvula(ajuste);
    }
}

// Ajusta o valor do PWM da ventoinha com base no ajuste calculado pelo controle PI.
void ajustaPwm(int ajuste) {
    int sinalPWM = pwm + ajuste;          // Soma o ajuste ao PWM atual
    sinalPWM = Limites(sinalPWM, 0, 1023); // Garante que o PWM fique dentro dos limites
    //pwm = sinalPWM;
    EPWM1_LoadDutyValue(sinalPWM); //O novo valor do PWM � carregado para controlar a velocidade do motor da ventoinha
}

// Ajusta a posi��o da v�lvula com base no ajuste calculado pelo controle PI.
void ajustaValvula(int ajuste) {
    //int novaPosicao = valvula_desejada + ajuste; // Soma o ajuste � posi��o da v�lvula, Se o erro for positivo, a v�lvula abre mais. Se for negativo, fecha.
    int novaPosicao = valvula + ajuste;
    //valvula_desejada = Limites(novaPosicao, 0, alturaMaximaMM); // Garante os limtes: O valor da v�lvula n�o pode ser menor que 0 (totalmente fechada) nem maior que alturaMaximaMM (totalmente aberta).
    novaPosicao = Limites(novaPosicao, 0, 470);
    //MANDAR MEXER A VALVULA COM A NOVA POSI��O
}


// Calibra��o e leitura da valvula
bool LeituraValvula(bool forcar_calibracao) {
    uint16_t valor_sensor = ADC_GetConversion(Lim);

    if (forcar_calibracao || (!calibracao&& valor_sensor < TCRT_THRESHOLD)) {
        //printf("Iniciando calibra��o da v�lvula...\n");

        while (valor_sensor < TCRT_THRESHOLD && passo_atual < MAX_PASSOS) {
            MoveValvula(true);
            __delay_ms(6);
            valor_sensor = ADC_GetConversion(Lim);
        }

        passo_atual = 0;
        calibracao= true;
        //printf("Calibra��o conclu�da! V�lvula na posi��o 0.\n");
    }

    return passo_atual;  // Retorna a posi��o atual da v�lvula
}

// controle da valvula
void MoveValvula(bool direcao) {
    static uint8_t passos = 0;

    if ((direcao && passo_atual >= MAX_PASSOS) || (!direcao && passo_atual == 0)) {
        return;
    }

    if (direcao) {
        passo_atual++;
        passos++;
        if (passos > 3) passos = 0;
    } else {
        passo_atual--;
        if (passos == 0) passos = 3;
        else passos--;
    }

    switch (passos) {
        case 0: SM1_SetHigh(); SM2_SetHigh(); SM3_SetLow(); SM4_SetLow(); break;
        case 1: SM1_SetLow(); SM2_SetHigh(); SM3_SetHigh(); SM4_SetLow(); break;
        case 2: SM1_SetLow(); SM2_SetLow(); SM3_SetHigh(); SM4_SetHigh(); break;
        case 3: SM1_SetHigh(); SM2_SetLow(); SM3_SetLow(); SM4_SetHigh(); break;
    }

    __delay_ms(3);
}

void AbreValvula() {
    while (passo_atual < MAX_PASSOS) {
        MoveValvula(true);
    }
    valvula_aberta = true;
    //printf("V�lvula totalmente aberta!\n");
}

void FechaValvula() {
    while (passo_atual > 0) {
        MoveValvula(false);
    }
    valvula_aberta = false;
    //printf("V�lvula totalmente fechada!\n");
}



/**
 End of File
*/