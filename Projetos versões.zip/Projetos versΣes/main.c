#include "mcc_generated_files/mcc.h"

// ----------------------------------------------- Comunica��o Serial ------------------------------------------------
// Defini��es
#define TAM_MAX 7                     // Tamanho m�ximo do buffer de recep��o
#define MODO_MANUAL 0                 // Comando para modo manual
#define MODO_VENTOINHA 1              // Comando para controle da ventoinha
#define MODO_VALVULA 2                // Comando para controle da v�lvula
#define MODO_RESET 3                  // Comando para reset
#define TAM_MENS_COMANDO 7            // Tamanho da mensagem de comando

// Estruturas para manipula��o de dados
typedef union {
    uint16_t VALOR16; // Valor de 16 bits
    struct {
        uint8_t LSB; // Byte menos significativo
        uint8_t MSB; // Byte mais significativo
    };
} DADOS; // Pacote de dados para transmiss�o e recep��o

// Vari�veis globais
DADOS TXdados;                  // Dados para transmiss�o
DADOS RXdados;                  // Dados recebidos
uint16_t altura_desejada = 0;   // Altura desejada (setpoint)
uint8_t Modo_Operacao = 0;      // Modo de opera��o (0 = manual, 1 = ventoinha, 2 = v�lvula)
uint16_t valor_PWM = 0;         // Ciclo de trabalho do PWM
uint16_t posicao_valvula = 0;   // Posi��o da v�lvula
uint8_t rxBuffer[TAM_MAX];      // Buffer de recep��o
uint8_t RX_Contador = 0;        // Contador de bytes recebidos
bool novos_dados = false;       // Flag para indicar novos dados recebidos

// Prot�tipos de fun��es
void processaDados();      // Processa os dados recebidos
void Enviadados();         // Envia dados via UART
void controla_ventoinha(); // Controla a ventoinha
void controla_valvula();   // Controla a v�lvula

// ----------------------------------------------- Fun��es de Comunica��o --------------------------------------------

/**
 * Processa os dados recebidos e executa o comando correspondente.
 */
void processaDados() {
    if (novos_dados) {
        switch (rxBuffer[0]) { // Verifica o comando recebido
            case MODO_MANUAL:   // Modo manual
                if (RX_Contador == TAM_MENS_COMANDO) {
                    Modo_Operacao = rxBuffer[0]; // Atualiza o modo de opera��o
                    RXdados.MSB = rxBuffer[3];
                    RXdados.LSB = rxBuffer[4];
                    posicao_valvula = RXdados.VALOR16; // Posi��o da v�lvula
                    if (posicao_valvula > 420) posicao_valvula = 420; // Limite m�ximo
                    if (posicao_valvula < 0) posicao_valvula = 0;     // Limite m�nimo
                    RXdados.MSB = rxBuffer[5];
                    RXdados.LSB = rxBuffer[6];
                    valor_PWM = RXdados.VALOR16; // Ciclo de trabalho do PWM
                    EPWM1_LoadDutyValue(valor_PWM); // Atualiza o PWM com o novo valor
                }
                RX_Contador = 0; // Reinicia o contador de bytes
                break;

            case MODO_VENTOINHA: // Modo ventoinha
                if (RX_Contador == TAM_MENS_COMANDO) {
                    Modo_Operacao = rxBuffer[0]; // Atualiza o modo de opera��o
                    controla_ventoinha(); // Chama a fun��o para controlar a ventoinha
                }
                RX_Contador = 0;
                break;

            case MODO_VALVULA: // Modo v�lvula
                if (RX_Contador == TAM_MENS_COMANDO) {
                    Modo_Operacao = rxBuffer[0]; // Atualiza o modo de opera��o
                    controla_valvula(); // Chama a fun��o para controlar a v�lvula
                }
                RX_Contador = 0;
                break;

            case MODO_RESET: // Comando de reset
                if (RX_Contador == TAM_MENS_COMANDO) {
                    RESET();
                }
                RX_Contador = 0;
                break;

            default:
                RX_Contador = 0;
                break;
        }
        novos_dados = false;
    }
}

/**
 * Controla a ventoinha com base nos dados recebidos.
 */
void controla_ventoinha() {
    RXdados.MSB = rxBuffer[1];
    RXdados.LSB = rxBuffer[2];
    altura_desejada = RXdados.VALOR16;
    RXdados.MSB = rxBuffer[3];
    RXdados.LSB = rxBuffer[4];
    posicao_valvula = RXdados.VALOR16;
    if (posicao_valvula > 420) posicao_valvula = 420;
    if (posicao_valvula < 0) posicao_valvula = 0;
}

/**
 * Controla a v�lvula com base nos dados recebidos.
 */
void controla_valvula() {
    RXdados.MSB = rxBuffer[1];
    RXdados.LSB = rxBuffer[2];
    altura_desejada = RXdados.VALOR16;
    RXdados.MSB = rxBuffer[5];
    RXdados.LSB = rxBuffer[6];
    valor_PWM = RXdados.VALOR16;
    EPWM1_LoadDutyValue(valor_PWM);
}

/**
 * Envia dados via UART.
 */
void Enviadados() {
    EUSART_Write(Modo_Operacao);
    TXdados.VALOR16 = altura_desejada;
    EUSART_Write(TXdados.MSB);
    EUSART_Write(TXdados.LSB);
    TXdados.VALOR16 = 950; // Substitua pelo valor real
    EUSART_Write(TXdados.MSB);
    EUSART_Write(TXdados.LSB);
    TXdados.VALOR16 = 1234; // Substitua pelo valor real
    EUSART_Write(TXdados.MSB);
    EUSART_Write(TXdados.LSB);
    TXdados.VALOR16 = 250; // Substitua pelo valor real
    EUSART_Write(TXdados.MSB);
    EUSART_Write(TXdados.LSB);
    TXdados.VALOR16 = posicao_valvula;
    EUSART_Write(TXdados.MSB);
    EUSART_Write(TXdados.LSB);
    TXdados.VALOR16 = valor_PWM;
    EUSART_Write(TXdados.MSB);
    EUSART_Write(TXdados.LSB);
}

// ----------------------------------------------- Loop Principal ------------------------------------------------
void main() {
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    uint8_t byteRecebido;

    while (1) {
        if (EUSART_is_rx_ready()) {
            byteRecebido = EUSART_Read();

            if (RX_Contador < TAM_MAX) {
                rxBuffer[RX_Contador++] = byteRecebido;
            }

            if (RX_Contador >= TAM_MENS_COMANDO) {
                novos_dados = true;
            }
        }

        if (novos_dados) {
            processaDados();
            novos_dados = false;
        }

        static uint16_t contadorTempo = 0;
        if (contadorTempo >= 100) {
            Enviadados();
            contadorTempo = 0;
        }
        __delay_ms(1);
        contadorTempo++;
    }
}
