           /**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name: Projeto Final Grupo 1 
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "main.h"
//#include <stdbool.h>

void main(void){
    // initialize the device
    SYSTEM_Initialize();
    TMR4_SetInterruptHandler(count10ms);
    TMR1_SetInterruptHandler(calculateToF);
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    while (1){
     
            if(EUSART_is_rx_ready()){           // Se chega um byte
                uint8_t rxChar = EUSART_Read(); // Se guarda em rxChar
                if (countRx < 7){
                    bufferRx[countRx] = rxChar;
                    countRx++;
                }
                if (countRx >= 7){
                    analisaRx();
                    countRx = 0;
                }
            }
            if (count_10ms == 10){
                enviaTx();
                count_10ms = 0;
            }
        LED_LAT = COMP;
    }
}

void calculateToF(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    
    while(!Echo_PORT);  // Aguarda borda de subida (in�cio do ECHO)
    TMR1_WriteTimer(0);
    TMR1_StartTimer();
    while(Echo_PORT);   // Aguarda borda de descida (fim do ECHO)
    TMR1_StopTimer();
    data.time_of_flight.total = TMR1_ReadTimer();
    // Converte de contagens de Timer1 para ms
    data.time_of_flight.total = data.time_of_flight.total * 0.00025;
}

void calculateHeight(){
    data.temperature.total = ADC_GetConversion(Temp);
    data.temperature.total = (uint16_t)( COEF *data.temperature.total);            // Converte valor para [�C] inteiro
    if (data.temperature.total < 0) data.temperature.total = 0;               // Temperatura m�nima em 0�C
    if (data.temperature.total > 50) data.temperature.total = 50;             // Temperatura m�xima em 50�C
    temperature_index =(uint16_t) data.temperature.total; 
    soundspeed_t = (uint16_t)LUTsoundspeed[temperature_index];                          //Calcula velocidade do som [m/s]
    data.height.total = (data.time_of_flight.total*soundspeed_t/2);         //Altura em [mm]
}

void count10ms(void) {
    count_10ms++;
}

void setpwm_dutycycle(){
    setpwm = data.dutycycle_pwm.total;       //Recebe valor do dutycycle com 16bits sem m�scara
    setpwm = ((uint16_t)data.dutycycle_pwm.MSB << 8) | data.dutycycle_pwm.LSB;
    setpwm &= 0x03FF;
    EPWM1_LoadDutyValue(setpwm);
}

void valvemotor(){

        uint8_t step = 0;
        if (COMP){
            data.pos_valve.total = 0;
            pos_motor = 0;
        }
        if(data.setpoint_valve.total < data.pos_valve.total){
            step++;
            pos_motor++;
            if(step == 4){
                step = 0;
            }
            if (pos_motor > 420){
                pos_motor = 420;
            }
        } 
        else if (data.setpoint_valve.total > data.pos_valve.total) {
                step--;
                pos_motor--;
                if(step == -1){
                    step = 3;
                }
                if (pos_motor == -1){
                pos_motor = 0;
                }
            }
        else{
                SM1_SetLow(); SM2_SetLow(); SM3_SetLow(); SM4_SetLow();
        }
    switch (step) {
        case 0: SM1_SetHigh(); SM2_SetHigh(); SM3_SetLow();  SM4_SetLow(); break;
        case 1: SM1_SetLow();  SM2_SetHigh(); SM3_SetHigh(); SM4_SetLow(); break;
        case 2: SM1_SetLow();  SM2_SetLow();  SM3_SetHigh(); SM4_SetHigh(); break;
        case 3: SM1_SetHigh(); SM2_SetLow();  SM3_SetLow();  SM4_SetHigh(); break;
    }
    data.pos_valve.total = (uint16_t)pos_motor;
}
void controlmode(){
    switch(data.funcmode){
        case VENTOINHA:
            ek = (float) data.setpoint_height.total - (float) data.height.total;
            ek = -ek;
            uk = KC * ((ek - ek_1) + ((T_Ti * (ek + ek_1)) / 2)) - uk_1;
            if (uk > 1023) {
                uk = 1023;
            } else if (uk < 0) {
                uk = 0;
            }
            data.dutycycle_pwm.total = (uint16_t) uk;
            uk_1 = uk;
            ek_1 = ek;
            break;
            
        case VALVULA: 
            ek = (float) data.setpoint_height.total - (float) data.height.total;
            uk = KC * ((ek - ek_1) + ((T_Ti * (ek - ek_1)) / 2)) - uk_1;
            if (uk > 420) {
                uk = 420;
            } else if (uk < 0) {
                uk = 0;
            }
            data.setpoint_valve.total = (uint16_t) uk;
            uk_1 = uk;
            ek_1 = ek;
            
            break;  
    }

}

void analisaRx(){
    switch(bufferRx[0]){
        case MANUAL:
            if (countRx==7){
                data.funcmode = bufferRx[0];
                data.setpoint_valve.MSB = bufferRx[3];
                data.setpoint_valve.LSB = bufferRx[4];
                data.dutycycle_pwm.MSB = bufferRx[5];
                data.dutycycle_pwm.LSB = bufferRx[6];
            }
            countRx = 0;
            break; 
        case VENTOINHA:
            if (countRx==7){
                data.funcmode = bufferRx[0];
                data.setpoint_height.MSB = bufferRx[1];
                data.setpoint_height.LSB = bufferRx[2];
                data.setpoint_valve.MSB = bufferRx[3];
                data.setpoint_valve.LSB = bufferRx[4];
            }
            countRx = 0;
            break;
        case VALVULA:
            if (countRx==7){
                data.funcmode = bufferRx[0];
                data.setpoint_height.MSB = bufferRx[1];
                data.setpoint_height.LSB = bufferRx[2];
                data.dutycycle_pwm.MSB = bufferRx[5];
                data.dutycycle_pwm.LSB = bufferRx[6];
            }
            countRx = 0;
            break;
        case RESET:
            if (countRx==7){
               RESET();
            }
            countRx = 0;
            break;
        default: 
            countRx = 0;
    }
    
}

void enviaTx(){
        EUSART_Write(data.funcmode);
        EUSART_Write(data.setpoint_height.MSB);
        EUSART_Write(data.setpoint_height.LSB);
        EUSART_Write(data.height.MSB);
        EUSART_Write(data.height.LSB);
        EUSART_Write(data.time_of_flight.MSB);
        EUSART_Write(data.time_of_flight.LSB);
        EUSART_Write(data.setpoint_valve.MSB);
        EUSART_Write(data.setpoint_valve.LSB);
        EUSART_Write(data.pos_valve.MSB);
        EUSART_Write(data.pos_valve.LSB);
        EUSART_Write(data.dutycycle_pwm.MSB);
        EUSART_Write(data.dutycycle_pwm.LSB);
}
