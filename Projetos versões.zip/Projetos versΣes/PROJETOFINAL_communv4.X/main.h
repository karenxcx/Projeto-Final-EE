/* 
 * File:   
 * Author: Grupo 1
 * Comments:
 * Revision history: 
 */
/*/PINOS 
 
 RA0 - Lim - Limite da v�lvula;        RB0 - Echo - sensor ultrassom; 
 RA1 - SM1 - Status Motor;             RB1 - UART_Rx - Bluetooth;
 RA2 - SM2 - Status Motor;             RB2 - UART_Tx - Bluetooth;
 RA3 - SM3 - Status Motor;             RB3 - Vent - aciona a ventoinha;
 RA4 - SM4 - Status Motor;             RB4 - Temp - Sensor de temperatura;
 RA5 - MCLR - faz nada;                RB5 - vazio
 RA6 - Trigger - sensor ultrassom;     RB6 - CSPCLK - faz nada;
 RA7 - LED - apenas um led;            RB7 - ICSPDAT - faz nada; 
 /*/

/*/Dados anal�gicos
 Sensor �ptico TCRT-5000 - 0V: valvula aberta, 5V: valvula fechada
 Sensor ultrassom HC-SR04 - altura da bola
 Sensor temperatura LM35 - compensa��o para altura da bola
 * Todos conectados em VDD = 5V; 
 * RA0: INPUT  - Lim     - sensor �ptico;
 * RA6: INPUT  - Echo    - sensor ultrassom;
 * RB4: INPUT  - Temp    - sensor de temperatura; 
 * RB0: OUTPUT - Trigger - sensor ultrassom;
 * RA7: OUTPUT - LED;
 /*/

/*/Comunica��o Bluetooth
 * UART
 * RB1 - UART_Rx: 7 bytes;
 *      CH0: Modo de funcionamento; 
 *      CH1: setpoint_1: MSB
 *      CH2: setpoint_1: LSB
 *      CH3: setpoint_2: MSB
 *      CH4: setpoint_2: LSB
 * RB2 - UART_Tx: 15 bytes;
 *      CH00: Modo de funcionamento; 
 *      CH01: setpoint_altura [mm]   : MSB
 *      CH02: setpoint_altura [mm]   : LSB
 *      CH03: altura medida   [mm]   : MSB
 *      CH04: altura medida   [mm]   : LSB 
 *      CH05: tempo_de_voo    [ms]   : MSB
 *      CH06: tempo_de_voo    [ms]   : LSB
 *      CH07: temperatura     [�C]   : MSB
 *      CH08: temperatura     [�C]   : LSB
 *      CH09: setpoint_valvula [step]: MSB
 *      CH10: setpoint_valvula [step]: LSB
 *      CH11: posicao_valvula  [step]: MSB
 *      CH12: posicao_valvula  [step]: LSB
 *      CH13: dutycycle_pwm  [0-1023]: MSB
 *      CH14: dutycycle_pwm  [0-1023]: LSB

 /*/

/*/Controle da Ventoinha
* RB3: PWM - Controle da ventoinha;             
 /*/

/*/Controle Motor de Passo ULN3003
* RA1: OUTPUT - SM1 - Status Motor;             
* RA2: OUTPUT - SM2 - Status Motor;             
* RA3: OUTPUT - SM3 - Status Motor;             
* RA4: OUTPUT - SM4 - Status Motor;             
 /*/

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <math.h>

/* Medi��o da Altura da Bola*/

#define T0      273.15       // [K]   - Temperatura em Kelvin a 0C;
#define C0      331.3        // [m/s] - Velocidade do som a 0C; 
#define COEF    0.0488       // Coeficiente para convers�o para 0C = 50/1023
    
#define COMP    CMOUTbits.MC1OUT

/* Vari�veis de controle PI*/

#define KC 1.0
#define T 0.01
#define Ti 0.01
#define Td 0.1

float T_Ti = T/Ti;

float ek = 0;
float ek_1 = 0;
float uk = 0;
float uk_1 = 0;

/* Modos de opera��o */

typedef enum {
    MANUAL, 
    VENTOINHA,
    VALVULA,
    RESET
}opmode; 

typedef union{
    uint16_t total;
    struct{
        uint8_t LSB;
        uint8_t MSB;
    };
} uint16_var;

typedef struct{
    uint8_t funcmode; 
    uint16_var setpoint_height; 
    uint16_var height; 
    uint16_var time_of_flight;
    uint16_var temperature;
    uint16_var setpoint_valve;
    uint16_var pos_valve;
    uint16_var dutycycle_pwm;
} TxData;
TxData data;

uint8_t bufferRx[7] = {0,0,0,0,0,0,0};
uint8_t countRx = 0, count_10ms = 0;
uint16_t setpwm = 0; 
int pos_motor = 0;
//float temperature_kelvin = 0, soundspeed = 0;
uint8_t temperature_index = 0;
uint16_t soundspeed_t;

void calculateHeight();        
void calculateToF();
void setpwm_dutycycle();
void valvemotor();
void controlmode();
void count10ms();
void analisaRx();
void enviaTx();

/*/Velocidade do som em [m/s] para temperaturas de 0�C a 50�C */
const float LUTsoundspeed[51] = {
    331.3,331.9,332.5,333.1,333.7,334.3,334.9,335.5,336.1,336.7,
    337.3,337.9,338.5,339.1,339.7,340.3,340.9,341.5,342.0,342.6,
    343.2,343.8,344.4,345.0,345.5,346.1,346.7,347.3,347.9,348.4,
    349.0,349.6,350.2,350.7,351.3,351.9,352.5,353.0,353.6,354.2,
    354.7,355.3,355.9,356.4,357.0,357.6,358.1,358.7,359.2,359.8,
    360.3};







#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

