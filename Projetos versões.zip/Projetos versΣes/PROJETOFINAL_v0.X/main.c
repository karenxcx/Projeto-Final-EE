/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "main.h"

void triggerUltrasonic(){
//    Trigger_SetHigh();
//    __delay_us(10);
//    Trigger_SetLow();
//    TMR1_Initialize();
}

void calculateToF(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    
    while(!Echo_PORT);  // Aguarda borda de subida (in�cio do ECHO)
    TMR1_WriteTimer(0);
    TMR1_StartTimer();
    while(Echo_PORT);   // Aguarda borda de descida (fim do ECHO)
    TMR1_StopTimer();
    time_of_flight = TMR1_ReadTimer();
    // Converte de contagens de Timer1 para ms
    time_of_flight = time_of_flight * 0.00025;
    
}

float calculateHeight(){
    temperature = ADC_GetConversion(Temp);
    temperature = (int)( COEF *(float) temperature);    // Converte valor para [�C] inteiro
    if (temperature < 0) temperature = 0;               // Temperatura m�nima em 0�C
    if (temperature > 50) temperature = 50;             // Temperatura m�xima em 50�C
    temperature_index = temperature; 
    soundspeed_t = LUTsoundspeed[temperature_index];            //Calcula velocidade do som [m/s]
    height = (time_of_flight*soundspeed/2);             //Altura em [mm]

}

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    
    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    while (1)
    {
        calculateHeight();
        calculateToF();
        __delay_ms(100);
    }
}
/**
 End of File
*/