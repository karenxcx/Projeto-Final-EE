           /**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name: Projeto Final Grupo 1 
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "main.h"
//#include <stdbool.h>

void main(void){
    // initialize the device
    SYSTEM_Initialize();
    TMR4_SetInterruptHandler(analisaRx);
    TMR1_SetInterruptHandler(calculateToF);

    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    while (1){
            if(EUSART_is_rx_ready()){           // Se chega um byte
                uint8_t rxChar = EUSART_Read(); // Se guarda em rxChar
                if (countRx < 7){
                    bufferRx[countRx] = rxChar;
                    countRx++;
                }
                if (countRx >= 7){
                    analisaRx();
                    countRx = 0;
                }
                if (count100ms >=10){
                    enviaTx();
                    count100ms = 0;
                }
                
            }

        }
}



//void atualizaDadosRecebidos() {
//    EPWM1_LoadDutyValue(dados.pwm.total);
//    novosDadosCadastrados = false;
//}

void calculateToF(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    
    while(!Echo_PORT);  // Aguarda borda de subida (in�cio do ECHO)
    TMR1_WriteTimer(0);
    TMR1_StartTimer();
    while(Echo_PORT);   // Aguarda borda de descida (fim do ECHO)
    TMR1_StopTimer();
    data.time_of_flight.total = TMR1_ReadTimer();
    // Converte de contagens de Timer1 para ms
    data.time_of_flight.total = data.time_of_flight.total * 0.00025;
}

void calculateHeight(){
    data.temperature.total = ADC_GetConversion(Temp);
    data.temperature.total = (int)( COEF *data.temperature.total);            // Converte valor para [�C] inteiro
    if (data.temperature.total < 0) data.temperature.total = 0;               // Temperatura m�nima em 0�C
    if (data.temperature.total > 50) data.temperature.total = 50;             // Temperatura m�xima em 50�C
    temperature_index = data.temperature.total; 
    soundspeed_t = LUTsoundspeed[temperature_index];                          //Calcula velocidade do som [m/s]
    data.height.total = (data.time_of_flight.total*soundspeed_t/2);         //Altura em [mm]
}

void analisaRx(){
    count40ms++;
    count100ms++;
    calculateHeight();
    if(count40ms == 4){
        count40ms = 0;
        data.funcmode = bufferRx[0];
        switch(data.funcmode){
            case MANUAL: 
                data.setpoint_valve.MSB = bufferRx[3];
                data.setpoint_valve.LSB = bufferRx[4];
                data.dutycycle_pwm.MSB = bufferRx[5];
                data.dutycycle_pwm.LSB = bufferRx[6];
                break; 
            case VENTOINHA: 
                data.setpoint_height.MSB = bufferRx[1];
                data.setpoint_height.LSB = bufferRx[2];
                data.setpoint_valve.MSB = bufferRx[3];
                data.setpoint_valve.LSB = bufferRx[4];
                break;
            case VALVULA: 
                data.setpoint_height.MSB = bufferRx[1];
                data.setpoint_height.LSB = bufferRx[2];
                data.dutycycle_pwm.MSB = bufferRx[5];
                data.dutycycle_pwm.LSB = bufferRx[6];
                break;
            case RESET: 
                RESET();
        }
    }
    enviaTx();
    

}

void enviaTx(){
    if (count100ms == 10){
        count100ms = 0;
        EUSART_Write(data.funcmode);
        EUSART_Write(data.setpoint_height.MSB);
        EUSART_Write(data.setpoint_height.LSB);
        EUSART_Write(data.height.MSB);
        EUSART_Write(data.height.LSB);
        EUSART_Write(data.time_of_flight.MSB);
        EUSART_Write(data.time_of_flight.LSB);
        EUSART_Write(data.setpoint_valve.MSB);
        EUSART_Write(data.setpoint_valve.LSB);
        EUSART_Write(data.pos_valve.MSB);
        EUSART_Write(data.pos_valve.LSB);
        EUSART_Write(data.dutycycle_pwm.MSB);
        EUSART_Write(data.dutycycle_pwm.LSB);
    }
}

////Fun��o para calcular o erro e retornar o ajuste que deve ser feito na ventoinha ou na v�lvula
//int ControleAjuste() {
//    float erroAtual = (float)(dados.height_desejada.total - dados.height.total); //Mede a diferen�a entre a altura desejada e a altura lida
//    erroAcumulado += erroAtual; //Soma o erro ao longo do tempo para eliminar o erro estacion�rio.
//    float deltaErro = erroAtual - erroAnterior; // Mede a taxa de varia��o do erro, ajudando a evitar oscila��es excessivas.
//    erroAnterior = erroAtual;
//    
//    return (int)(ganhoK * erroAtual + tempoK * erroAcumulado + ganhoD * deltaErro); //C�lculo da sa�da do controlador PI
//}
//
//void Controle() {
//    //Alterar_PWM = enviado = false;
//    int ajuste = ControleAjuste();        // Obt�m o valor de ajuste necess�rio para reduzir o erro entre o valor medido e o valor desejado.
//    if (dados.Modo_Operacao == VENTOINHA) {     // Se o sistema est� no modo VENTOINHA, chama ajustaPwm
//        ajustaPwm(ajuste);
//    } else {                              // Se est� no modo VALVULA, chama ajustaValvula
//        ajustaValvula(ajuste);
//    }
//}
//
//// Ajusta o valor do PWM da ventoinha com base no ajuste calculado pelo controle PI.
//void ajustaPwm(int ajuste) {
//    int sinalPWM = dados.pwm.total + ajuste;          // Soma o ajuste ao PWM atual
//    sinalPWM = Limites(sinalPWM, 0, 1023); // Garante que o PWM fique dentro dos limites
//    //pwm = sinalPWM;
//    EPWM1_LoadDutyValue(sinalPWM); //O novo valor do PWM � carregado para controlar a velocidade do motor da ventoinha
//}
//
//// Ajusta a posi��o da v�lvula com base no ajuste calculado pelo controle PI.
//void ajustaValvula(int ajuste) {
//    //int novaPosicao = valvula_desejada + ajuste; // Soma o ajuste � posi��o da v�lvula, Se o erro for positivo, a v�lvula abre mais. Se for negativo, fecha.
//    int novaPosicao = dados.valvula.total + ajuste;
//    //valvula_desejada = Limites(novaPosicao, 0, alturaMaximaMM); // Garante os limtes: O valor da v�lvula n�o pode ser menor que 0 (totalmente fechada) nem maior que alturaMaximaMM (totalmente aberta).
//    novaPosicao = Limites(novaPosicao, 0, 470);
//    //MANDAR MEXER A VALVULA COM A NOVA POSI��O
//}
//
//// Calibra��o e leitura da valvula
//bool LeituraValvula(bool forcar_calibracao) {
//    uint16_t valor_sensor = ADC_GetConversion(Lim);
//
//    if (forcar_calibracao || (!calibracao&& valor_sensor < TCRT_THRESHOLD)) {
//        //printf("Iniciando calibra��o da v�lvula...\n");
//
//        while (valor_sensor < TCRT_THRESHOLD && passo_atual < MAX_PASSOS) {
//            MoveValvula(true);
//            __delay_ms(6);
//            valor_sensor = ADC_GetConversion(Lim);
//        }
//
//        passo_atual = 0;
//        calibracao= true;
//    }
//
//    return passo_atual;  // Retorna a posi��o atual da v�lvula
//}
//
//// controle da valvula
//void MoveValvula(bool direcao) {
//    static uint8_t passos = 0;
//
//    if ((direcao && passo_atual >= MAX_PASSOS) || (!direcao && passo_atual == 0)) {
//        return;
//    }
//
//    if (direcao) {
//        passo_atual++;
//        passos++;
//        if (passos > 3) passos = 0;
//    } else {
//        passo_atual--;
//        if (passos == 0) passos = 3;
//        else passos--;
//    }
//
//    switch (passos) {
//        case 0: SM1_SetHigh(); SM2_SetHigh(); SM3_SetLow(); SM4_SetLow(); break;
//        case 1: SM1_SetLow(); SM2_SetHigh(); SM3_SetHigh(); SM4_SetLow(); break;
//        case 2: SM1_SetLow(); SM2_SetLow(); SM3_SetHigh(); SM4_SetHigh(); break;
//        case 3: SM1_SetHigh(); SM2_SetLow(); SM3_SetLow(); SM4_SetHigh(); break;
//    }
//
//    __delay_ms(3);
//}
//
//void AbreValvula() {
//    while (passo_atual < MAX_PASSOS && !LeituraValvula(false)) {
//        MoveValvula(true);  // Move no sentido hor�rio
//    }
//    valvula_aberta = true;
//    //printf("V�lvula totalmente aberta!\n");
//}
//
//void FechaValvula() {
//    while (passo_atual > 0) {
//        MoveValvula(false);
//    }
//    valvula_aberta = false;
//    //printf("V�lvula totalmente fechada!\n");
//}
