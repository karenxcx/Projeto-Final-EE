/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name: Projeto Final Grupo 1
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "main.h"
#include <stdbool.h>

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
   // LeituraValvula(true);  // Realiza calibra��o no in�cio
    Modo_Operacao=0;
    height_desejada=0;
    height=0;
    pwm = 700;
    EPWM1_LoadDutyValue(pwm);
    triggerUltrasonic();
    calculateHeight();
    calculateToF();
            

    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    while (1)
    {
        //  verificar como est� a valvula se j� est� calibrada 
       //if (!calibracao) {
        //    Leitura_Valvula();                  // Realiza calibra��o, se necess�rio
          //  calibracao = true;  // Se a v�lvula j� estiver fechada, a calibra��o est� conclu�da
      // } 
       
        if (Modo_Operacao == VENTOINHA || Modo_Operacao == VALVULA) { // Se o modo de opera��o for ventoinha ou valvula, chama a fun��o de controle PID
        
            Controle();
        }
        else if (Modo_Operacao == MANUAL) {
            //Move_Valvula;
             bool valvula_fechada = Leitura_Valvula();
            if(!valvula_fechada){                   // Se a v�lvula n�o estiver fechada
             //Valvula fechada
                Move_Valvula(true);                 // Abre a v�lvula (sentido hor�rio)
            } else {   //Valvula aberta             // daqui veio p if calibra��o 
                Move_Valvula(false);                // Fecha a v�lvula (sentido anti-hor�rio)
            }
            EPWM1_LoadDutyValue(pwm);
        }
        
        else if (Modo_Operacao == RESET_) {
            asm("reset"); // Reseta o Pic
        }
   
          
           
        //Lim_SetLow();
        //enviarDados();
        //if (EUSART_is_rx_ready()) {
        //    processaRecepcaoUSART();
       // } else if (novosDadosCadastrados) {
       //     atualizaDadosRecebidos();
      //  }
        
       
    }
}

void processaRecepcaoUSART() {
    for (int i = 0; i < 8; i++) {
        rxbuffer[i] = EUSART_Read();
    }

  //  dados.Modo_Operacao = rxbuffer[0];
   /// dados.height_desejada.bytes[1] = rxbuffer[1];
  //  dados.height_desejada.bytes[0] = rxbuffer[2];
    dados.valvula_desejada.bytes[1] = rxbuffer[3];
    dados.valvula_desejada.bytes[0] = rxbuffer[4];
  //  dados.pwm.bytes[1] = rxbuffer[5];
   // dados.pwm.bytes[0] = rxbuffer[6];

//    novosDadosCadastrados = true;
}

void atualizaDadosRecebidos() {
//    EPWM1_LoadDutyValue(dados.pwm.total);
//    novosDadosCadastrados = false;
}

void enviarDados() {
    uint8_t pacote[12];
    
    //pacote[0] = dados.Modo_Operacao;
   // pacote[1] = dados.height_desejada.bytes[1];
   // pacote[2] = dados.height_desejada.bytes[0];
   // pacote[3] = dados.height.bytes[1];
  //  pacote[4] = dados.height.bytes[0];
   // pacote[5] = dados.time_of_flight.bytes[1];
  //  pacote[6] = dados.time_of_flight.bytes[0];
   // pacote[7] = (uint8_t)dados.temp_t;
  //  pacote[8] = dados.valvula_desejada.bytes[1];
  //  pacote[9] = dados.valvula_desejada.bytes[0];
  //  pacote[10] = dados.valvula.bytes[1];
  //  pacote[11] = dados.valvula.bytes[0];
//
    for (size_t i = 0; i < sizeof(pacote); i++) {
        EUSART_Write(pacote[i]);
    }
}

void triggerUltrasonic(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    TMR1_Initialize();
}

void calculateToF(){
    Trigger_SetHigh();
    __delay_us(10);
    Trigger_SetLow();
    
    while(!Echo_PORT);  // Aguarda borda de subida (in�cio do ECHO)
    TMR1_WriteTimer(0);
    TMR1_StartTimer();
    while(Echo_PORT);   // Aguarda borda de descida (fim do ECHO)
    TMR1_StopTimer();
    dados.time_of_flight.total = TMR1_ReadTimer();
    // Converte de contagens de Timer1 para ms
    dados.time_of_flight.total = (uint16_t)(dados.time_of_flight.total * 0.00025);
    
}

float calculateHeight(){
    temperature = ADC_GetConversion(Temp);
    temperature = (uint16_t)(COEF * (float)temperature);    // Converte valor para [�C] inteiro
    if ((int)temperature < 0) temperature = 0;               // Temperatura m�nima em 0�C
    if (temperature > 50) temperature = 50;             // Temperatura m�xima em 50�C
    temperature_index = (uint8_t)temperature;
    dados.temp_t = temperature;
    soundspeed_t = (uint16_t)LUTsoundspeed[temperature_index];            //Calcula velocidade do som [m/s]
    height = (dados.time_of_flight.total*soundspeed/2);             //Altura em [mm]
    

}

//Fun��o para calcular o erro e retornar o ajuste que deve ser feito na ventoinha ou na v�lvula
int ControleAjuste() {
    if (height_desejada > height){
         erroAtual = (float)(height_desejada - height); //Mede a diferen�a entre a altura desejada e a altura lida
    }
    else {
         erroAtual = (float)(height - height_desejada); //Mede a diferen�a entre a altura desejada e a altura lida
    }
    erroAcumulado += erroAtual; //Soma o erro ao longo do tempo para eliminar o erro estacion�rio.
    float deltaErro = erroAtual - erroAnterior; // Mede a taxa de varia��o do erro, ajudando a evitar oscila��es excessivas.
    erroAnterior = erroAtual;
    
    return (int)(ganhoK * erroAtual + tempoK * erroAcumulado + ganhoD * deltaErro); //C�lculo da sa�da do controlador PI
}

void Controle() {
    int ajuste = ControleAjuste();        // Obt�m o valor de ajuste necess�rio para reduzir o erro entre o valor medido e o valor desejado.
    if (Modo_Operacao == VENTOINHA) {     // Se o sistema est� no modo VENTOINHA, chama ajustaPwm
        ajustaPwm(ajuste);
    } else {                              // Se est� no modo VALVULA, chama ajustaValvula
        ajustaValvula(ajuste);
    }
}

// Ajusta o valor do PWM da ventoinha com base no ajuste calculado pelo controle PI.
void ajustaPwm(int ajuste) {
    if (height_desejada > height){
         sinalPWM = (int)pwm + (int)ajuste;          // Soma o ajuste ao PWM atual
    }
    else {
         sinalPWM = (int)pwm - (int)ajuste;          // Subtrai o ajuste ao PWM atual
    }
    
    sinalPWM = Limites(sinalPWM, 0, 1023); // Garante que o PWM fique dentro dos limites
    //pwm = sinalPWM;
    EPWM1_LoadDutyValue((uint16_t)sinalPWM); //O novo valor do PWM � carregado para controlar a velocidade do motor da ventoinha
    estado_atual = 3;
    Horario();
}

// Ajusta a posi��o da v�lvula com base no ajuste calculado pelo controle PI.
void ajustaValvula(int ajuste) {
    // Soma o ajuste � posi��o da v�lvula, Se o erro for positivo, a v�lvula abre mais. Se for negativo, fecha.
    int novaPosicao = (int)estado_atual + (int)ajuste;
    // Garante os limtes: O valor da v�lvula n�o pode ser menor que 0 (totalmente fechada) nem maior que alturaMaximaMM (totalmente aberta).
    novaPosicao = Limites(novaPosicao, 0, 420);
    EPWM1_LoadDutyValue(pwm);

    //Chama a fun��o que controla a valvula
}

// Calibra��o e leitura da valvula
bool Leitura_Valvula() {  
    uint16_t valor_Lim = ADC_GetConversion(Lim); // L� o valor anal�gico de RA0
    
    //Valvula fechada
    if (valor_Lim > Limiar_sensor) {            // Se a valvula � maior que o vaor limiar_sensor ent�o ..  
       return true;                             // Lim = 1 est� fechada, ent�o retorna verdadeiro
    }
    
    //Valvula aberta
    if (!calibracao) {                          // Se a v�lvula n�o estiver fechada e ainda n�o foi calibrada, calibramos
        while (valor_Lim < Limiar_sensor && estado_atual < MAX_PASSOS) { 
            estado_atual=1;
            anti_Horario();                     // Fecha a v�lvula estado a estado (sentido anti-hor�rio)
           // __delay_ms(3);          
           estado_atual --;                       
           //estado_atual++;                     // Incrementa corretamente o estado_atual
           valor_Lim = ADC_GetConversion(Lim);  // Atualiza a leitura do sensor
        }
        estado_atual = 0;                       // Define que a v�lvula est� na posi��o inicial
        calibracao = true;                      // Marca que a calibra��o foi conclu�da
    }
    return false;                               // Retorna falso a v�lvula ainda n�o est� fechada
}

// controle da valvula
void Move_Valvula(bool direcao){
    if (Modo_Operacao == VALVULA){
           if (novaPosicao < estado_atual) {
            Horario();
            estado_atual++;
          // estado_atual--; inverter qualquer coisa
        } else if (novaPosicao > estado_atual){               // se n�o fecha v�lvula sentido anti horario
         anti_Horario();
         estado_atual--;
        }
    } else { // Modo manual
        if ( valvula_desejada < estado_atual) {
          Horario();
          estado_atual++;
          // estado_atual--; inverter qualquer coisa
        } else if ( valvula_desejada > estado_atual) {               // se n�o fecha v�lvula sentido anti horario
            anti_Horario();
            estado_atual--;
        }
    }
}

void Horario() {
    estado_motor = estado_atual; 
    switch (estado_motor) {
        case 0: SM1_SetHigh(); SM2_SetHigh(); SM3_SetLow(); SM4_SetLow(); break;
        case 1: SM1_SetLow(); SM2_SetHigh(); SM3_SetHigh(); SM4_SetLow(); break;
        case 2: SM1_SetLow(); SM2_SetLow(); SM3_SetHigh(); SM4_SetHigh(); break;
        case 3: SM1_SetHigh(); SM2_SetLow(); SM3_SetLow(); SM4_SetHigh(); break;
    }
    // estado_motor = (estado_motor + 1) & 3;   // Alterna entre caso 0 e 3 d             
    //estado_motor = (estado_motor + 1) % 4;    // Em vez de & 3
    estado_motor++;
    estado_motor =  estado_motor & 0x03;
     //__delay_ms(3);
}

void anti_Horario() {                 
   estado_motor = estado_atual; 
    switch (estado_motor) {
        case 0: SM1_SetHigh(); SM2_SetLow(); SM3_SetLow(); SM4_SetHigh(); break;
        case 1: SM1_SetLow(); SM2_SetLow(); SM3_SetHigh(); SM4_SetHigh(); break;
        case 2: SM1_SetLow(); SM2_SetHigh(); SM3_SetHigh(); SM4_SetLow(); break;
        case 3: SM1_SetHigh(); SM2_SetHigh(); SM3_SetLow(); SM4_SetLow(); break;
    }
    //estado_motor = (estado_motor - 1) & 3;      // Alterna entre 0 e 3 sem valores negativos              
   //estado_motor = (estado_motor - 1 + 4) % 4;
    estado_motor++;
    estado_motor =  estado_motor & 0x03;
    //__delay_ms(3);
}